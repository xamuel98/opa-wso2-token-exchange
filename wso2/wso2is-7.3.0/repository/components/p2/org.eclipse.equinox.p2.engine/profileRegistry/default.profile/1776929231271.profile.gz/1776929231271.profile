<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='default' timestamp='1776929231271'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/workspace/platform-builds/carbon-kernel_4.12.x/carbon-kernel/target/checkout/distribution/kernel/target/WSO2Carbon'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86,osgi.ws=gtk,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/workspace/platform-builds/carbon-kernel_4.12.x/carbon-kernel/target/checkout/distribution/kernel/target/WSO2Carbon/default'/>
  </properties>
</profile>
